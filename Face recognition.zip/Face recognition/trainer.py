import os
import cv2
import numpy as np
from PIL import Image

recognizer=cv2.face.LBPHFaceRecognizer_create()
path='C:\\Users\\Anshuman Singh\\Desktop\\New folder\\Dataset1'

def getImagesWithID(path):
    imgPaths=[os.path.join(path,f) for f in os.listdir(path)]# joining  path to each image in dataset
    faces=[]
    Ids=[]
    for imgPath in imgPaths:
        faceImg=Image.open(imgPath).convert("L")# converting image to gray
        faceNp=np.array(faceImg,'uint8')# coverting gray image to array
        ID=int(os.path.split(imgPath)[-1].split('.')[1])# it finds the id associated with each image in dataset.
        #(Path is split and last path that is image in dataset is found which is again split on the basis of '.' and second part is found by giving [1] . The second part is ID
        faces.append(faceNp)
        Ids.append(ID)
        cv2.imshow("traning", faceNp)
        cv2.waitKey(100)
    return np.array(Ids), faces

Ids, faces=getImagesWithID(path)
recognizer.train(faces,Ids)
recognizer.save("recognizer/trainingData.yml")
cv2.destroyAllWindows()
